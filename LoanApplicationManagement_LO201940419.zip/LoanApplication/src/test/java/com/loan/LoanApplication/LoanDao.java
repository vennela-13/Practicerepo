package com.loan.LoanApplication;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.ILoanDao;
import com.capgemini.xyz.dao.LoanDao;

class LoanDaoTest {
	static LoanDao dao; 
	static Customer c;
	static Loan l;
	@BeforeAll
	public static void daoTest()
	{
		dao = new LoanDao();
		c = new Customer(null, null, 0, null);
		l = new Loan(0, 0, 0, 0);
	}
	@Test
	void testApplyLoan() {
		c.setCustName("Manasa");
		c.setAddress("Hyd");
		c.setEmail("manasa123@gmail.com");
		c.setMobile(954756378);
		long id = dao.insertCust(c);
		l.setCustId(id);
		l.setLoanAmount(10000);
		l.setDuration(4);
		l.setLoanID(0);
		assertEquals(10000, dao.applyLoan(l));
	}
	
}