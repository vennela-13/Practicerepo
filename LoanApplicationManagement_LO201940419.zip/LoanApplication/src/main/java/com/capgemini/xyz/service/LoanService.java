package com.capgemini.xyz.service;

import javax.naming.InvalidNameException;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.ILoanDao;
import com.capgemini.xyz.dao.LoanDao;

public class LoanService implements ILoanService {
	// pojo loan object
	Loan loan=new Loan(0, 0, 0, 0);
	// creating object for dao layer
	ILoanDao daoObj=new LoanDao();
public long applyLoan(Loan loan) {
	return 0;
	}
public Customer validateCustomer(Customer customer) {

	int c = 0;
	if(isValidName(customer.getCustName()))
	{
		if(isMobileNoValid(customer.getMobile()))
		{
			if(isValidAddress(customer.getAddress()))
			{
				c++;
			}
			else
			{
				try {
					throw new InValidAddressException();
				} catch (InValidAddressException e) {
					
				}
			}
		}
		else
		{
			try {
				throw new InValidMobileNoException();
			} catch (InValidMobileNoException e) {
			}
		}
	}
	else
	{
		try {
			throw new InvalidNameException();
		} catch (InvalidNameException e) {
		}
	}
	if(c != 0)
		return customer;
	else
	return null;
}

private boolean isMobileNoValid(long mobile) {  // To check if the given mobile no is correct or not
	if(Long.toString(mobile).length() == 10)
		return true;
	else
	return false;
}

private boolean isValidAddress(String address) {  // To check if the given address is correct or not
	return address.matches( 
	         "[a-zA-Z0-9]*" );
}

private boolean isValidName(String custName) { // To check if the given username is correct or not
	return custName.matches( "[A-Z][a-zA-Z]*" );
}

public long insertCust1(Customer cust) {
	return daoObj.insertCust(cust);
}
	public long insertCust(Customer cust) {
	return daoObj.insertCust(cust);
	}
public double calculateEMI(double amount, int duration) {
	final double rate=9.5;
		 double EMI=loan.getLoanAmount()*rate*(1+rate)*loan.getDuration()*12/((1+rate)*loan.getDuration()*12-1);
		return EMI;
	
}

}
