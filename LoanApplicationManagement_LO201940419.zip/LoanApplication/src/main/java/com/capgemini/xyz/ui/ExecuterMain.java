package com.capgemini.xyz.ui;
import java.util.*;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.service.ILoanService;
import com.capgemini.xyz.service.LoanService;

public class ExecuterMain {
public static void main(String args[]) {
	// customer pojo class object
	Customer custObj=new Customer(null, null, 0, null);
	//loan pojo class object
	 Loan loanObj=new Loan(0, 0, 0, 0);
	 // service class object
	 ILoanService serviceObj=new LoanService();
	 System.out.println("XYZ Finance Company welcomes you\n 1. Register Customer\n 2. Exit ");
	 Scanner input=new Scanner(System.in);
	 int ch=input.nextInt();
	 switch(ch)
	 {
	 case 1:
		 // entering all the details and storing them in customer pojo class object
		System.out.println("Enter customer name ");
		custObj.setCustName(input.next());
		System.out.println("Enter Address");
		custObj.setAddress(input.next());
		System.out.println("Enter Email");
		custObj.setEmail(input.next());
		System.out.println("Enter mobile no");
		custObj.setMobile(input.nextLong());
		
		// passing all these values to the service layer using service object
		serviceObj.insertCust(custObj);
		long customerId=custObj.getCustId();
		System.out.println("Customer information saved successfully. your Customer Id is " +customerId );
		
		System.out.println("Do you wish to apply for loan? (Yes/ No)");
		String ch1=input.next();
	 switch(ch1)
	 {
	 case "Yes":
		System.out.println("Enter loan amount");
		loanObj.setLoanAmount(input.nextDouble());
		System.out.println("Enter loan duration");
		loanObj.setDuration(input.nextInt());
		// calculating the EMI
		System.out.println("For Loan amount <"+loanObj.getLoanAmount()+">and <"+loanObj.getDuration()+"> Years duration.");
		double amount=serviceObj.calculateEMI(loanObj.getLoanAmount(), loanObj.getDuration());
		System.out.println("Your EMI per month will be <"+amount+">");
		
		break;
		
		// If the customer does not wish to apply for the loan, display the customer details
		case "No":
		 System.out.println("customer Id is:" +custObj.getCustId());
		 System.out.println("Name is:" +custObj.getCustName());
		 System.out.println("Address is:" +custObj.getAddress());
		 System.out.println("Mobile no is:" +custObj.getMobile());
		 System.out.println("Email Id is:" +custObj.getEmail());
		 break;
	 }
	 case 2:
		 System.out.println("Thank You!!!");
		 System.exit(0);
		 break;
	 }
}
}
