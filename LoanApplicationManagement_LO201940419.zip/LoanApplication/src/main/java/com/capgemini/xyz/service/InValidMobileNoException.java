package com.capgemini.xyz.service;

public class InValidMobileNoException extends Exception {

}
