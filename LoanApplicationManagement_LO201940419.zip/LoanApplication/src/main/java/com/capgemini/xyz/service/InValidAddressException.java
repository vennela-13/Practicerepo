package com.capgemini.xyz.service;

public class InValidAddressException extends Exception {

}
