package com.capgemini.xyz.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public class LoanDao implements ILoanDao {
	Customer customer=new Customer(null, null, 0, null);
	public long insertCust(Customer cust) {
		customerEntry=new HashMap();
		Random random=new Random();  // generating customer Id randomly
		customer.setCustId(random.nextLong());
		//getting all the values into customerEntry using customer pojo class object
		customerEntry.put(customer.getCustId(),new Customer(customer.getCustName(),customer.getAddress(),customer.getMobile(),customer.getEmail()));
		return 0;
		
	}
	
	public long applyLoan(Loan loan) {
loanEntry.put(loan.getLoanID(), new Loan(loan.getLoanID(),loan.getLoanAmount(),loan.getCustId(),loan.getDuration()));
		
		if(loan.getLoanID() == loanEntry.get(loan.getLoanID()).getLoanID())
			return loan.getLoanID();
		else
		return 0;
		
	}
	private Map<Long, Customer> customerEntry;
	private Map<Long, Loan> loanEntry;

}

